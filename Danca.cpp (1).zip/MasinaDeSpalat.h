#ifndef MASINADESPALAT_H
#define MASINADESPALAT_H
#include "Produs.h"
#include <string>
#include "MasinaDeSpalat.h"
//clasa MasinaDeSpalat care extinde clasa Produs si are membrii: rotatiiPeMinut si clasaEnergetica
class MasinaDeSpalat : public Produs{
public:
    MasinaDeSpalat() {};
    MasinaDeSpalat(const string& nume, const int& id, const double& pret, const int& RotatiiPeMinut, const string& clasaEnergetica);
    int getRotatiiPeMinut();
    string getClasaEnergetica();
    void print();
    //virtual ~Masina() {};
private:
    int RotatiiPeMinut;
    string clasaEnergetica;
};



#endif // MASINADESPALAT_H










