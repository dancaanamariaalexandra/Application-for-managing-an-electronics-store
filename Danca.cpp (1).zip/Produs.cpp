#include "Produs.h"
#include <iostream>
using namespace std;

Produs::Produs(const string& NUME, const int& ID, const double& P):
 nume(NUME), id(ID), pret(P)
{}
Produs::Produs() {}



int Produs::getId() {
    return id;
}


string Produs::getNume() {
    return nume;
}


double Produs::getPret() {
    return pret;
}


void Produs::print() {
    cout << nume <<" "<< id <<" "<< pret << endl;
}


ostream& operator<<(ostream& OP, const Produs &P) {
    OP << P.nume <<" "<< P.id <<" "<< P.pret;
    return OP;
}

Produs::~Produs(){}
