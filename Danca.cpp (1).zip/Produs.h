#ifndef PRODUS_H
#define PRODUS_H
#include <string>
using namespace std;
//clasa de baza care are membrii: nume, id,  pret
class Produs {
public:
    Produs(const string& nume, const int& ID, const double& PRET);
    Produs();
    int getId();
    double getPret();
    string getNume();
    friend ostream& operator <<(ostream& OP, const Produs& produs);
    virtual void print();
    virtual ~Produs();
protected:
    int id;
    double pret;
    string nume;
};









#endif//PRODUS_H

