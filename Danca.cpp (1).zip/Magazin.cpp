#include "Magazin.h"
#include "Produs.h"
#include "Frigider.h"
#include "MasinaDeSpalat.h"

#include <string>
#include <vector>

#include <stdexcept>
#include <exception>
#include <iostream>
using namespace std;

Magazin::Magazin(const int& n) : nrProduse(n) { };

void Magazin::adaugaProdus(Produs *produs) {
    if(PRD.size() >= nrProduse)
        throw string("MagazinPlinException");
    PRD.push_back(new Produs());
    PRD[PRD.size()-1] = produs;
}
void Magazin::eliminaProdus(int idProdus) {
    for(int i=0; i<PRD.size(); i++) {
        if(PRD[i]->getId() == idProdus){
            PRD.erase(PRD.begin() + i);
            return;
        }
    }

    throw string("ProdusInexistentException");

}

Produs* Magazin::cautaProdus(int idProdus) {
    for(int i=0; i<PRD.size(); i++) {
        if(PRD[i]->getId() == idProdus){
            return PRD[i];
        }
    }

    throw string("ProdusInexistentException");
}

int Magazin::numaraMasiniDeSpalat() {
    int ix = 0;
    for(int i=0; i<PRD.size(); i++) {
        if(dynamic_cast<MasinaDeSpalat*>(PRD[i]))
            ix++;
    }
    return ix;
}

void Magazin::scrieProduse() {
    for(int i=0; i<PRD.size(); i++)
        PRD[i]->print();

}
