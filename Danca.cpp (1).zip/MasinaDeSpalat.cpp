#include "MasinaDeSpalat.h"
#include <iostream>
using namespace std;

MasinaDeSpalat::MasinaDeSpalat(const string& NUME, const int& ID, const double& PRET, const int& RotatiiPeMinut, const string& ClasaEnergetica) :
 Produs(NUME, ID, PRET),
RotatiiPeMinut(RotatiiPeMinut),
 clasaEnergetica(ClasaEnergetica)
 {}

int MasinaDeSpalat::getRotatiiPeMinut() {
    return RotatiiPeMinut;
}
void MasinaDeSpalat::print(){
    cout<<nume<<" rotatii : "<<RotatiiPeMinut<<" id : "<<id<<" clasa : "<<clasaEnergetica<<endl;
}
string MasinaDeSpalat::getClasaEnergetica(){
    return clasaEnergetica;
}
