
#ifndef FRIGIDER_H
#define FRIGIDER_H

#include "Produs.h"
#include <string>

class Frigider : public Produs {
public:
    Frigider(const string& NUME, const int& ID, const int& P, const int& VOLUM, bool ARECONGELATOR);
    virtual ~Frigider() { };
    int getVolum();
    int getId();
    bool getAreCongelator();
    void ScrieDetalii();
    friend ostream& operator <<(ostream& OP, const Frigider& F); //suprascriere operator


private:
    int volum;
    bool areCongelator;
};








#endif // FRIGIDER_H
