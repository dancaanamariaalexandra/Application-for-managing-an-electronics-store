#include "Frigider.h"
#include <iostream>
using namespace std;


Frigider::Frigider(const string& NUME, const int& ID, const int& P, const int& VOLUM, bool ARECONGELATOR):
 Produs(NUME, ID, P),
 volum(VOLUM),
 areCongelator(ARECONGELATOR)
 {}

int Frigider::getVolum(){
    return volum;
}


bool Frigider::getAreCongelator(){
    return areCongelator;
}




void Frigider::ScrieDetalii(){
    cout<< nume << " id: "<< id << " pret : " << pret << " volum : " << volum << " congelator : "  << areCongelator << endl;
}



ostream& operator<<(ostream& OP, const Frigider& F) {
    OP << F.nume <<" "<< F.id <<" "<< F.pret <<" "<< F.volum <<" "<< F.areCongelator;
    return OP;
}
