

#ifndef MAGAZIN_H
#define MAGAZIN_H

#include "Produs.h"
#include "Frigider.h"
#include "MasinaDeSpalat.h"
#include <string>
#include <vector>
class Magazin {
public:
    Magazin() {};
    Magazin(const int& n);
    virtual ~Magazin() {};

    void adaugaProdus(Produs *produs); /**adauga un produs in agazin**/
    void eliminaProdus(int idProdus);  // throws MagazinPlinException
    Produs* cautaProdus(int idProdus);  // throws ProdusInexistentException
    int numaraMasiniDeSpalat();

    void scrieProduse();
private:
    vector<Produs*> PRD;
    int masiniDeSpalat;
    int nrProduse;
};

#endif // MAGAZIN_H
