#include <iostream>
#include "Produs.h"
#include "Frigider.h"
#include "MasinaDeSpalat.h"
#include "Magazin.h"

using namespace std;

int main()
{
    int n;
    cout << "Numarul maxim de produse este : ";
    cin >> n;
    Magazin MAGAZIN(n);


    string nume, ClasaEnergetica;
    int id,  RotatiiPeMinut, volum;
    double pret;
    bool ARECONGELATOR;
    bool OK = true;
    while(OK) {
    cout << "Ce actiune se executa?\n";
    cout << "[A] - Adauga produs\n";
    cout << "[E] - Elimina produs\n";
    cout << "[C] - Cauta produs\n";
    cout << "[N] - Numara masini de spalat\n";
    cout << "[L] - scrie produse\n";
    char optiune, litera;
    cin >> optiune;
    switch (optiune)
    {
    case 'A':
        cout << "Frigider(F) sau Masina de spalat(M)?\n";
        cin >> litera;
        if(litera == 'F') {
            cout << "Nume: "; cin >> nume;
            cout << "ID: "; cin >> id;
            cout << "Pret: "; cin >> pret;
            cout << "Volum: "; cin >> volum;
            cout << "Are congelator? 1 - Da / 0 - Nu : "; cin >> ARECONGELATOR;

            try {
                MAGAZIN.adaugaProdus(new Frigider(nume, id, pret, volum, ARECONGELATOR));
                cout << "Frigider adaugat in magazinul meu\n";
            } catch (string& exceptie) {
                cout << exceptie << endl;
            }
        }
        else if(litera == 'M') {
            cout << "Nume: "; cin >> nume;
            cout << "ID: "; cin >> id;
            cout << "Pret: "; cin >> pret;
            cout << "Rotatii pe minut: "; cin >>  RotatiiPeMinut;
            cout << "Clasa energetica: "; cin >> ClasaEnergetica;
            MAGAZIN.adaugaProdus(new MasinaDeSpalat(nume, id, pret,  RotatiiPeMinut, ClasaEnergetica));
        }
        break;

    case 'E':
        try {
            cout << "ID-ul produsului de eliminat: "; cin >> id;
            MAGAZIN.eliminaProdus(id);
        } catch(string& exceptie) {
            cout << exceptie << endl;
        }

        break;

    case 'C':
        cout << "ID-ul produsului cautat: "; cin >> id;
        try {
            cout << "Produsul gasit: \n";
            MAGAZIN.cautaProdus(id)->print();
        }
        catch(string& exceptie) {
            cout << exceptie << endl;
        }

        break;

    case 'N':
        cout << MAGAZIN.numaraMasiniDeSpalat() << endl;
        break;

    case 'L':
        MAGAZIN.scrieProduse();
        break;
    default:
        OK = false;
        break;
    }
    }


    return 0;
}
